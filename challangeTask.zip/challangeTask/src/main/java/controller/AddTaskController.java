package controller;

import DbConnection.DbConnection;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;

public class AddTaskController {

    @FXML
    private DatePicker dateid;

    @FXML
    private JFXTextArea descriptionid;

    @FXML
    private JFXTextField titleid;

    @FXML
    void btnAdd(ActionEvent event) {

        String title = titleid.getText();
        String description = descriptionid.getText();
        Date date = Date.valueOf(dateid.getValue());

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();

        String insertQuery = "INSERT INTO tasks (task_title, task_description, completion_date) " +
                "VALUES ('" + title + "', '" + description + "', '" + date + "')";

        try {
            int rows = statement.executeUpdate(insertQuery);
            if (rows>0) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Success");
                alert1.setHeaderText(null);
                alert1.setContentText("Task Added Successfully");
                alert1.showAndWait();

                titleid.setText("");
                descriptionid.setText("");
                date.toLocalDate();
            }
            else {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Failed");
                alert1.setHeaderText(null);
                alert1.setContentText("Task Fail to Add ");
                alert1.showAndWait();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

}
