package controller;

import DbConnection.DbConnection;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Task;

import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class ViewCompletedTaskController implements Initializable {

    @FXML
    private JFXButton btnsearch;

    @FXML
    private TableColumn<?, ?> coldate;

    @FXML
    private TableColumn<?, ?> coldescription;

    @FXML
    private TableColumn<?, ?> coltitle;

    @FXML
    private TableView<Task> tableid;

    @FXML
    private JFXTextField txtsearchid;

    @FXML
    void btnsearch(ActionEvent event) {

        String title  =txtsearchid.getText();

        tableid.getItems().clear();

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();

        String searchQuery = "SELECT * FROM completed_tasks WHERE task_title LIKE '%" + title + "%'";
        try {
            ResultSet resultSet = statement.executeQuery(searchQuery);
            while (resultSet.next()){
                int taskId = resultSet.getInt("task_id");
                String taskTitle = resultSet.getString("task_title");
                String taskDescription = resultSet.getString("task_description");
                Date completionDate = resultSet.getDate("completion_date");

                Task task = new Task(taskId, taskTitle, taskDescription, completionDate);
                tableid.getItems().add(task);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    public  void ViewTable() {

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();
        ObservableList<Task> taskObservableList = FXCollections.observableArrayList();
        String viewquery = "SELECT * FROM completed_tasks";

        try {
            ResultSet resultSet = statement.executeQuery(viewquery);
            while (resultSet.next()) {
                int id = resultSet.getInt("task_id");
                String title = resultSet.getString("task_title");
                String description = resultSet.getString("task_description");
                Date date = resultSet.getDate("completion_date");

                Task task = new Task(id,title,description,date);
                taskObservableList.add(task);

                coltitle.setCellValueFactory(new PropertyValueFactory<>("title"));
                coldescription.setCellValueFactory(new PropertyValueFactory<>("description"));
                coldate.setCellValueFactory(new PropertyValueFactory<>("date"));

                tableid.setItems(taskObservableList);


            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ViewTable();
    }
}
