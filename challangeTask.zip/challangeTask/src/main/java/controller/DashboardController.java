package controller;

import DbConnection.DbConnection;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Task;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class DashboardController  implements Initializable {

    @FXML
    private JFXButton btnsearch;

    @FXML
    private TableView<Task> tableid;

    @FXML
    private TableColumn<?, ?> coldate;

    @FXML
    private TableColumn<?, ?> coldescription;

    @FXML
    private TableColumn<?, ?> coltitle;

    @FXML
    private JFXTextField txtsearchid;

    @FXML
    void btnDeleteTask(ActionEvent event) {

        Task selectedtask = tableid.getSelectionModel().getSelectedItem();
        if (selectedtask!=null) {
            String taskname  =selectedtask.getTitle();

            DbConnection dbConnection = DbConnection.getInstance();
            Statement statement = dbConnection.getStatment();

            String deleteQuery = "DELETE FROM tasks WHERE task_title='" + taskname + "'";

            try {
                int rowsDeleted = statement.executeUpdate(deleteQuery);
                if (rowsDeleted > 0) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Task Deleted Successfully");
                    alert.showAndWait();


                    ViewTable();
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Deletion Failed");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to delete the Task. Please try again.");
                    alert.showAndWait();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


        }

    }

    @FXML
    void btnUpdateTask(ActionEvent event) {

        Task selectedtask = tableid.getSelectionModel().getSelectedItem();
        if (selectedtask!=null) {
            String title = selectedtask.getTitle();
            String description = selectedtask.getDescription();
            Date date = selectedtask.getDate();


            FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/UpdateTaskUI.fxml"));
            try {
                Parent root = loader.load();
                UpdateTaskController controller = loader.getController();
                controller.setId(selectedtask.getId());
                controller.setTitle(title);
                controller.setDescription(description);
                controller.setDate(date);

                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();

            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(" Failed");
            alert.setHeaderText(null);
            alert.setContentText("Please Select  task.");
            alert.showAndWait();

        }


    }

    @FXML
    void btnViewCompletedTask(ActionEvent event) {

        Stage stage = new Stage();
        try {
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/ViewCompletedTask.fxml"))));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stage.show();

    }

    @FXML
    void btnaddTask(ActionEvent event) {

        Stage stage = new Stage();
        try {
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("../view/addTaskUI.fxml"))));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stage.show();


    }

    @FXML
    void btncompleteTask(ActionEvent event) {
        Task selectedtask = tableid.getSelectionModel().getSelectedItem();
        if (selectedtask!=null) {

            String taskName = selectedtask.getTitle();
            String taskDescription = selectedtask.getDescription();
            Date completionDate = selectedtask.getDate();
            int taskId = selectedtask.getId();

            DbConnection dbConnection = DbConnection.getInstance();
            Statement statement = dbConnection.getStatment();

            String insertQuery = "INSERT INTO completed_tasks (task_title, task_description, completion_date) " +
                    "VALUES ('" + taskName + "', '" + taskDescription + "', '" + completionDate + "')";

            try {
                statement.executeUpdate(insertQuery);
                String deleteQuery = "DELETE FROM tasks WHERE task_id = " + taskId;
                int rowsDeleted =statement.executeUpdate(deleteQuery);
                if (rowsDeleted > 0) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setHeaderText(null);
                    alert.setContentText("Task Completed Successfully");
                    alert.showAndWait();


                    ViewTable();
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle(" Failed");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to Complete the Task. Please try again.");
                    alert.showAndWait();
                }


            } catch (SQLException e) {
                throw new RuntimeException(e);
            }


        }


    }

    @FXML
    void btnsearch(ActionEvent event) {

        String title  =txtsearchid.getText();

        tableid.getItems().clear();

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();

        String searchQuery = "SELECT * FROM tasks WHERE task_title LIKE '%" + title + "%'";
        try {
            ResultSet resultSet = statement.executeQuery(searchQuery);
            while (resultSet.next()){
                int taskId = resultSet.getInt("task_id");
                String taskTitle = resultSet.getString("task_title");
                String taskDescription = resultSet.getString("task_description");
                Date completionDate = resultSet.getDate("completion_date");

                Task task = new Task(taskId, taskTitle, taskDescription, completionDate);
                tableid.getItems().add(task);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    @FXML
    void btnReloadTasks(ActionEvent event) {
        ViewTable();
    }

    public  void ViewTable() {

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();
        ObservableList<Task> taskObservableList = FXCollections.observableArrayList();
        String viewquery = "SELECT * FROM tasks";

        try {
            ResultSet resultSet = statement.executeQuery(viewquery);
            while (resultSet.next()) {
                int id = resultSet.getInt("task_id");
                String title = resultSet.getString("task_title");
                String description = resultSet.getString("task_description");
                Date date = resultSet.getDate("completion_date");

                Task task = new Task(id,title,description,date);
                taskObservableList.add(task);

                coltitle.setCellValueFactory(new PropertyValueFactory<>("title"));
                coldescription.setCellValueFactory(new PropertyValueFactory<>("description"));
                coldate.setCellValueFactory(new PropertyValueFactory<>("date"));

                tableid.setItems(taskObservableList);


            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ViewTable();

    }
}

