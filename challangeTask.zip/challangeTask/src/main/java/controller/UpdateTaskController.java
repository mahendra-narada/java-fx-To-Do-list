package controller;

import DbConnection.DbConnection;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateTaskController {

    @FXML
    private DatePicker dateid;

    @FXML
    private JFXTextArea descriptionid;

    @FXML
    private JFXTextField titleid;

    int originaId;
    public void setId(int ID) {
        originaId = ID;
    }


    public void setTitle(String title) {
        titleid.setText(title);
    }

    public void setDescription(String description) {
        descriptionid.setText(description);
    }

    public void setDate(Date date) {
        dateid.setValue(date.toLocalDate());
    }

    @FXML
    void btnUpdate(ActionEvent event) {

        String title = titleid.getText();
        String description = descriptionid.getText();
        Date date = Date.valueOf(dateid.getValue());

        DbConnection dbConnection = DbConnection.getInstance();
        Statement statement = dbConnection.getStatment();

        String updateQuery = "UPDATE tasks SET task_title = '" + title + "', task_description = '" + description + "', completion_date = '" + date + "' WHERE task_id  = " + originaId;

        try {
            int rowsUpdated = statement.executeUpdate(updateQuery);
            if (rowsUpdated>0) {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Success");
                alert1.setHeaderText(null);
                alert1.setContentText("Task Updated Successfully");
                alert1.showAndWait();
            }
            else {
                Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
                alert1.setTitle("Failed");
                alert1.setHeaderText(null);
                alert1.setContentText("Task Cannot be Updated");
                alert1.showAndWait();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

}
