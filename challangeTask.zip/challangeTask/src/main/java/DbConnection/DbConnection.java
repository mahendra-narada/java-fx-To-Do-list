package DbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnection {

    private static DbConnection instance;
    //sql connection instance
    private Connection connection;

    //Singleton Dbconnection
    public static DbConnection getInstance() {

        return null== instance ? instance = new DbConnection() : instance;
    }

    private DbConnection() {
        String url = "jdbc:mysql://localhost:3306/Todolist";
        String username = "root";
        String password = "1234";

        try {
            connection = DriverManager.getConnection(url,username,password);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    //Statment create method

    public Statement getStatment() {
        try {
            return connection.createStatement();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
